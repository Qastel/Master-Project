class Color:
    GAME_COLOR = (230, 230, 230)
    WHITE = (255, 255, 255)
    RED = (255, 0, 0)
    BLACK = (0, 0, 0)
