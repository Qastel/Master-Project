from alien_invasion import AlienInvasion

AlienInvasion().run_game()
