import pygame


def hide_mouse_cursor():
    pygame.mouse.set_visible(False)
